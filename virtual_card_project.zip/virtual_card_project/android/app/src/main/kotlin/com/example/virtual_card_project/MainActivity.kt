package com.example.virtual_card_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
